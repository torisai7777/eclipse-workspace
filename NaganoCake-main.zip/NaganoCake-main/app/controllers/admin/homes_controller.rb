class Admin::HomesController < ApplicationController
  def top
  end
end
